
/* Anime wallpaper */
(function(){var s=document.createElement("script");s.src="/custom/anime-wallpaper.js?v=6";document.head.appendChild(s)})();
