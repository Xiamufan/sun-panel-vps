(() => {
  if (window.__animeWallpaper) return;
  window.__animeWallpaper = true;
  const key = 'sun-anime-wallpaper-v1';
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(key) || '{}'); } catch {}
  const settings = { motion: true, interval: 120, source: 'hd', custom: '', ...saved };
  if (!settings.qualityUpgrade && settings.source !== 'custom') { settings.source = 'hd'; settings.qualityUpgrade = true; }
  let pool = [], remaining = [], catalogLoadedAt = 0;
  let busy = false, timer, current = '', active;
  const style = document.createElement('style');
  style.textContent = `
    #anime-scene{position:fixed;inset:0;pointer-events:none;z-index:0;overflow:hidden;background:#15243b}
    #anime-scene .anime-media{position:absolute;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity 1.2s;transform:scale(1.02)}
    #anime-scene .anime-media.ready{opacity:1}
    #anime-scene.moving .anime-media{animation:anime-pan 28s ease-in-out infinite alternate}
    #anime-scene:after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,rgba(7,14,30,.12),rgba(7,14,30,.30))}
    body.anime-wallpaper-ready .wallpaper{opacity:0!important}
    #anime-scene .spark{position:absolute;bottom:-20px;width:5px;height:5px;border-radius:50%;background:#fff9;box-shadow:0 0 12px #aaddff;opacity:0}
    #anime-scene.moving .spark{animation:anime-float 16s linear infinite}
    @keyframes anime-pan{from{transform:scale(1.02) translate(-.6%,-.4%)}to{transform:scale(1.06) translate(.6%,.4%)}}
    @keyframes anime-float{0%{transform:translateY(0);opacity:0}15%,75%{opacity:.65}100%{transform:translate(60px,-110vh);opacity:0}}
    #anime-tools{position:fixed;left:18px;bottom:18px;z-index:1000;font:14px system-ui;color:#fff;max-width:calc(100vw - 36px)}
    #anime-tools button,#anime-tools select,#anime-tools input{font:inherit;color:inherit;border:1px solid #ffffff30;border-radius:10px;background:#17233ee8;padding:9px 12px}
    #anime-tools button{cursor:pointer}#anime-tools button:disabled{opacity:.5;cursor:wait}#anime-tools button:hover{background:#35486deb}
    #anime-tools .bar{display:flex;gap:6px}#anime-tools .panel{margin-bottom:8px;padding:16px;border:1px solid #ffffff30;border-radius:16px;background:#14213af2;box-shadow:0 10px 30px #0004;width:300px;max-width:calc(100vw - 36px);box-sizing:border-box;backdrop-filter:blur(16px)}
    #anime-tools .panel[hidden]{display:none}#anime-tools label{display:block;margin:12px 0 5px}#anime-tools select,#anime-tools input[type=url]{width:100%;box-sizing:border-box}#anime-tools input[type=checkbox]{accent-color:#a9c6ff}
    #anime-tools .hint{font-size:12px;color:#c0cce0;line-height:1.6;margin:10px 0 0}#anime-status{font-size:12px;padding:6px 3px;max-width:310px;text-shadow:0 1px 3px #000}
    @media(prefers-reduced-motion:reduce){#anime-scene .anime-media,#anime-scene .spark{animation:none!important}}
    @media(max-width:600px){#anime-tools{left:12px;bottom:12px}#anime-tools button{padding:8px 10px}}
  `;
  document.head.append(style);
  const scene = document.createElement('div'); scene.id = 'anime-scene'; scene.setAttribute('aria-hidden','true');
  for (let i=0;i<14;i++) { const spark=document.createElement('i');spark.className='spark';spark.style.left=`${i*7+2}%`;spark.style.animationDelay=`${-i*1.7}s`;spark.style.animationDuration=`${14+i%5*3}s`;scene.append(spark); }
  document.body.prepend(scene);
  const tools=document.createElement('div');tools.id='anime-tools';
  tools.innerHTML=`<div class="panel" hidden><strong>二次元壁纸</strong><label for="anime-source">在线壁纸来源</label><select id="anime-source"><option value="hd">精选二次元 · 4K 原图</option><option value="xxapi">二次元 · 小小 API</option><option value="ospyo">动漫 · OSPYO</option><option value="custom">自定义图片 / 动态视频</option></select><label for="anime-custom">自定义链接（HTTPS）</label><input id="anime-custom" type="url" placeholder="图片、GIF 或 MP4 / WebM 链接"><label for="anime-interval">自动更换</label><select id="anime-interval"><option value="0">关闭，手动更换</option><option value="60">每 1 分钟</option><option value="120">每 2 分钟</option><option value="300">每 5 分钟</option><option value="600">每 10 分钟</option></select><label><input id="anime-motion" type="checkbox"> 动态效果 · 缓慢运镜与浮光</label><button id="anime-apply" type="button">应用设置</button><p class="hint">支持静音循环视频。设置保存在当前浏览器；加载失败会保留当前壁纸。</p></div><div class="bar"><button id="anime-next" type="button">✦ 换一张</button><button id="anime-settings" type="button" aria-expanded="false">壁纸设置</button></div><div id="anime-status" role="status" aria-live="polite"></div>`;
  document.body.append(tools);
  const $=id=>document.getElementById(id), status=text=>$('anime-status').textContent=text;
  $('anime-source').value=settings.source;$('anime-custom').value=settings.custom;$('anime-interval').value=String(settings.interval);$('anime-motion').checked=settings.motion;
  function persist(){try{localStorage.setItem(key,JSON.stringify(settings))}catch{} }
  function schedule(){clearInterval(timer);scene.classList.toggle('moving',settings.motion);if(settings.interval && settings.source!=='custom')timer=setInterval(()=>{if(!document.hidden)change()},settings.interval*1000)}
  async function onlineUrl(){
    if(settings.source==='hd'){
      if(!pool.length || Date.now()-catalogLoadedAt>300000){const response=await fetch('/custom/hd-wallpapers.json?t='+Date.now(),{cache:'no-store'});const updated=await response.json();const known=new Set(pool.map(x=>x.url));remaining.push(...updated.filter(x=>!known.has(x.url)));pool=updated;catalogLoadedAt=Date.now();}
      if(!remaining.length)remaining=pool.slice().sort(()=>Math.random()-.5);
      return remaining.pop().url;
    }
    if(settings.source==='custom'){const u=new URL(settings.custom);if(u.protocol!=='https:')throw new Error('请填写 HTTPS 图片或视频链接');return u.href;}
    if(settings.source==='ospyo')return `https://wallpaper.ospyo.com/api/v2/anime?t=${Date.now()}`;
    const response=await fetch(`https://v2.xxapi.cn/api/randomAcgPic?type=${innerWidth<600?'wap':'pc'}&return=json&t=${Date.now()}`,{signal:AbortSignal.timeout(18000),credentials:'omit',referrerPolicy:'no-referrer'});
    const data=await response.json();if(Number(data.code)!==200 || typeof data.data!=='string')throw new Error('在线壁纸暂时不可用');
    const url=new URL(data.data);if(url.protocol!=='https:')throw new Error('壁纸链接不可用');return url.href;
  }
  function load(url){return new Promise((resolve,reject)=>{
    const video=/\.(mp4|webm)(\?|$)/i.test(url);const media=document.createElement(video?'video':'img');media.className='anime-media';media.referrerPolicy='no-referrer';
    let timeout=setTimeout(()=>finish(new Error('壁纸加载超时，请重试或更换来源')),25000);
    function finish(error){clearTimeout(timeout);media.onerror=null;media.onload=null;media.onloadeddata=null;if(error){media.remove();reject(error)}else{if(video)media.play().catch(()=>{});resolve(media)}}
    if(video){media.muted=true;media.loop=true;media.autoplay=true;media.playsInline=true;media.onloadeddata=()=>finish();}else{media.alt='';media.onload=()=>finish();}
    media.onerror=()=>finish(new Error('图片或视频无法加载，请换一张'));media.src=url;scene.prepend(media);
  })}
  async function change(){
    if(busy)return;busy=true;$('anime-next').disabled=true;$('anime-apply').disabled=true;status('正在寻找新壁纸…');
    try{let url=await onlineUrl();if(url===current && settings.source!=='custom')url=await onlineUrl();const next=await load(url);const previous=active;active=next;current=url;requestAnimationFrame(()=>next.classList.add('ready'));document.body.classList.add('anime-wallpaper-ready');setTimeout(()=>previous?.remove(),1400);status('');}
    catch(error){status(error.message || '暂时无法更换，请重试');}
    finally{busy=false;$('anime-next').disabled=false;$('anime-apply').disabled=false;}
  }
  $('anime-next').onclick=change;
  $('anime-settings').onclick=()=>{const panel=tools.querySelector('.panel');panel.hidden=!panel.hidden;$('anime-settings').setAttribute('aria-expanded',String(!panel.hidden));};
  $('anime-apply').onclick=()=>{settings.source=$('anime-source').value;settings.custom=$('anime-custom').value.trim();settings.interval=Number($('anime-interval').value);settings.motion=$('anime-motion').checked;persist();schedule();change();};
  document.addEventListener('visibilitychange',()=>{if(active?.tagName==='VIDEO'){if(document.hidden)active.pause();else active.play().catch(()=>{})}});
  schedule();change();
})();
