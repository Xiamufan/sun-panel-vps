import json, os, sys, time, urllib.request, urllib.parse
from pathlib import Path
root=Path('/opt/sun-panel/conf/custom')
catalog=root/'hd-wallpapers.json'
statefile=Path('/opt/sun-panel/wallpaper-state.json')
items=json.loads(catalog.read_text()) if catalog.exists() else []
state=json.loads(statefile.read_text()) if statefile.exists() else {'page':1}
known={item['url'] for item in items}
success=0
for _ in range(int(sys.argv[1]) if len(sys.argv)>1 else 4):
    params=urllib.parse.urlencode(dict(categories='010',purity='100',atleast='3840x2160',sorting='date_added',ratios='16x9',page=state['page']))
    try:
        request=urllib.request.Request('https://wallhaven.cc/api/v1/search?'+params,headers={'User-Agent':'SunPanelWallpaper/1.0'})
        with urllib.request.urlopen(request,timeout=25) as response: data=json.load(response)
        for item in data['data']:
            if item['path'] not in known and item['dimension_x']>=3840 and item['dimension_y']>=2160:
                items.append({'url':item['path'],'resolution':item['resolution'],'page':item['url']})
                known.add(item['path'])
        state['page']=state['page']+1 if state['page']<data['meta']['last_page'] else 1
        success+=1
    except Exception as error:
        print('Fetch failed:',error,flush=True)
        break
    time.sleep(2)
if success:
    temp=catalog.with_suffix('.tmp')
    temp.write_text(json.dumps(items,ensure_ascii=False),encoding='utf-8')
    os.replace(temp,catalog)
    statefile.write_text(json.dumps(state))
print('Wallpaper catalog:',len(items),'Next page:',state['page'],flush=True)
if not success: sys.exit(1)
