import json,urllib.request,urllib.parse,time
for query in ['blue archive','genshin impact','honkai star rail','arknights','azur lane','touhou','hatsune miku','bocchi the rock','frieren','neon genesis evangelion']:
    params=urllib.parse.urlencode(dict(q=query,purity='100',atleast='2560x1440',ratios='landscape',sorting='date_added',page=1))
    try:
        req=urllib.request.Request('https://wallhaven.cc/api/v1/search?'+params,headers={'User-Agent':'SunPanelWallpaper/2.0'})
        with urllib.request.urlopen(req,timeout=20) as r:d=json.load(r)
        print(query,d['meta']['total'],[(x['id'],x['resolution']) for x in d['data'][:2]],flush=True)
    except Exception as e:print(query,str(e),flush=True)
    time.sleep(1.2)
